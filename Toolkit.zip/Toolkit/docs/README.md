# docs
Documenting architecture of OpenPecha, components and standards
