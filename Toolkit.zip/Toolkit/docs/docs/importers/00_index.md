# Introduction

Openpecha Importers are just plugins that import text into OPF.
