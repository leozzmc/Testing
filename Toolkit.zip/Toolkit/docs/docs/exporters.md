# OpenPecha Exporters

OpenPecha Exporters are just plugins that export text in OPF (OpenPecha's native format)  to other format such as .epub, .docx, etc.
