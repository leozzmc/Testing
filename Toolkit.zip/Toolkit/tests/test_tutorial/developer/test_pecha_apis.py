from docs_src.developer.pecha import create_new_pecha


def test_create_pecha():
    create_new_pecha.pecha
