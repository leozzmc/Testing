
class Collections:
  
  def get_all(self):
    pass
  
  
class Collection:
  
  def bundle_items(self, items=[]):
    pass
  
  def export(self, format=None):
    pass
  
