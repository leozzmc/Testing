class PechaNotFound(Exception):
    pass
