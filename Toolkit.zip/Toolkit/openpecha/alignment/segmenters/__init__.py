class Segmenter:

    def segment(self):
        raise NotImplementedError
