class Collated:
  
  def create_base(self):
    pass
  
  def update_base(self):
    pass
  
  def find_diffs(self):
    pass
  
  def segment(self):
    pass
