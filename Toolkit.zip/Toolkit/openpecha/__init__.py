# Version of openpecha-toolkit package
__version__ = "0.8.22"
